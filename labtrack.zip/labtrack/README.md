# 🧪 LabTrack: Sistem Peminjaman dan Inventaris Lab Berbasis Web dengan QR Code

Sistem manajemen laboratorium berbasis web untuk memudahkan peminjaman alat, pelacakan inventaris, dan integrasi QR Code.

## 🔧 Fitur Utama
- Manajemen inventaris lengkap (alat, bahan, ruang lab)
- Peminjaman & pengembalian dengan scan QR Code
- Multi-role user: Admin, Petugas Lab, Mahasiswa/Dosen
- Dashboard real-time dengan grafik
- Notifikasi keterlambatan pengembalian
- Log aktivitas sistem
- Ekspor laporan (PDF/Excel)
- Responsive & mobile-friendly

## 🛠️ Teknologi
- PHP 8+
- MySQL
- Bootstrap 5
- JavaScript (Chart.js, HTML5-QRCode)
- Library: `endroid/qr-code`, `phpmailer`, `PhpSpreadsheet`

## 🚀 Instalasi
1. Clone repositori ini
2. Buat database `labtrack_db`
3. Jalankan skrip `database/schema.sql`
4. Jalankan `composer install` (untuk library QR Code, dll)
5. Akses via `http://localhost/labtrack`

## 👤 Default Login
- **Admin**: admin@labtrack.com / admin123
- **Petugas**: petugas@labtrack.com / petugas123

> ⚠️ Ganti password default setelah login pertama!

---

Dikembangkan oleh: Tim LabTrack  
Versi: 1.0.0
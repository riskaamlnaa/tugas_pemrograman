<?php
$pageTitle = $pageTitle ?? 'Dashboard';
require_once __DIR__ . '/functions.php';
requireLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> - <?= esc($pageTitle) ?></title>
    <!-- Bootstrap CSS -->
    <link href="<?= BASE_URL ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons - DIPERBAIKI (menghilangkan spasi ekstra) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom CSS -->
    <link href="<?= BASE_URL ?>assets/css/custom.css" rel="stylesheet">
    <link rel="icon" href="<?= BASE_URL ?>assets/images/logo.png">
</head>
<body class="d-flex flex-column min-vh-100">

    <!-- Navbar Atas -->
    <nav class="navbar navbar-dark bg-gradient-primary shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="<?= BASE_URL ?>pages/dashboard/index.php">
                <img src="<?= BASE_URL ?>assets/images/logo.png" width="30" height="30" class="me-2 rounded">
                <strong><?= APP_NAME ?></strong>
            </a>
            <div class="d-flex align-items-center">
                <span class="text-white me-3"><?= esc($_SESSION['name']) ?></span>
                <a href="<?= BASE_URL ?>pages/auth/logout.php" class="btn btn-outline-light btn-sm">Keluar</a>
            </div>
        </div>
    </nav>

    <!-- Flash Message -->
    <?php showFlash(); ?>
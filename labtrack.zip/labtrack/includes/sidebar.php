<?php
// Pastikan session aktif
$role = $_SESSION['role'] ?? 'user';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <div class="px-3 py-3">
                    <h6 class="mb-0">LabTrack</h6>
                </div>

                <ul class="nav flex-column mt-3">

                    <!-- Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'dashboard') !== false ? 'active fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/dashboard/index.php">
                            <i class="bi bi-house me-2"></i> Dashboard
                        </a>
                    </li>

                    <!-- Inventaris -->
                    <li class="nav-item">
                        <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'inventory') !== false ? 'active fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/inventory/index.php">
                            <i class="bi bi-flask me-2"></i> Inventaris
                        </a>
                    </li>

                    <!-- Peminjaman -->
                    <li class="nav-item">
                        <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'bookings') !== false ? 'active fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/bookings/index.php">
                            <i class="bi bi-calendar-check me-2"></i> Peminjaman
                        </a>
                    </li>

                    <!-- Log Aktivitas -->
                    <?php if ($role !== 'user'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'activity_log') !== false ? 'active fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/activity_log/index.php">
                            <i class="bi bi-clipboard-data me-2"></i> Log Aktivitas
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- Pengguna -->
                    <?php if ($role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= strpos($_SERVER['REQUEST_URI'], 'users') !== false ? 'active fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/users/index.php">
                            <i class="bi bi-people me-2"></i> Pengguna
                        </a>
                    </li>
                    <?php endif; ?>

                    <!-- Profil Saya -->
                    <li class="nav-item mt-4">
                        <a class="nav-link text-primary <?= strpos($_SERVER['REQUEST_URI'], 'profile') !== false ? 'fw-bold' : '' ?>" 
                           href="<?= BASE_URL ?>pages/profile/index.php">
                            <i class="bi bi-person me-2"></i> Profil Saya
                        </a>
                    </li>

                </ul>

                <!-- Role User -->
                <div class="mt-auto px-3 pb-3">
                    <hr>
                    <small class="text-muted">
                        Role: <span class="badge rounded-pill
                            <?= $role == 'admin' ? 'bg-danger' : 
                                ($role == 'petugas' ? 'bg-warning' : 'bg-info') ?>">
                            <?= ucfirst($role) ?>
                        </span>
                    </small>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
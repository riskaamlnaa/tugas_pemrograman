<?php
if (!isset($_SESSION)) session_start();

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . BASE_URL . "pages/auth/login.php");
        exit();
    }
}

function requireRole($roles) {
    requireLogin();
    if (!in_array($_SESSION['role'], $roles)) {
        header("Location: " . BASE_URL . "pages/errors/403.php");
        exit();
    }
}
?>
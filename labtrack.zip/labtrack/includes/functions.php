<?php
// Fungsi Escape HTML
function esc($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// Fungsi Format Tanggal
function formatDate($date) {
    return $date ? date('d M Y H:i', strtotime($date)) : '-';
}

// Fungsi Flash Message
function flashMessage($msg, $type = 'info') {
    $_SESSION['flash_message'] = $msg;
    $_SESSION['flash_type'] = $type;
}

// Fungsi Tampilkan Flash Message
function showFlash() {
    if (isset($_SESSION['flash_message'])) {
        $type = $_SESSION['flash_type'] ?? 'info';
        $class = match($type) {
            'error' => 'alert-danger',
            'success' => 'alert-success',
            'warning' => 'alert-warning',
            default => 'alert-info'
        };
        echo '<div class="alert ' . $class . ' alert-dismissible fade show">' . esc($_SESSION['flash_message']) . '
              <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
        unset($_SESSION['flash_message'], $_SESSION['flash_type']);
    }
}

// Fungsi Cetak Laporan (versi modern)
function printReport($title, $data, $columns) {
    echo "<div class='report-container'>";
    echo "<h3 class='text-center mb-4'>" . esc($title) . "</h3>";
    echo "<table class='table table-bordered'>";
    echo "<thead class='table-light'><tr>";
    
    // Header tabel
    foreach ($columns as $col) {
        echo "<th class='py-2'>" . esc(ucwords(str_replace('_', ' ', $col))) . "</th>";
    }
    echo "</tr></thead><tbody>";
    
    // Isi tabel
    foreach ($data as $row) {
        echo "<tr>";
        foreach ($columns as $key) {
            $value = $row[$key] ?? '-';
            // Format tanggal jika kolom created_at
            if ($key == 'created_at' && $value != '-') {
                $value = date('d M Y H:i', strtotime($value));
            }
            echo "<td class='py-2 px-3'>" . esc($value) . "</td>";
        }
        echo "</tr>";
    }
    
    echo "</tbody></table>";
    echo "<p class='text-end mt-4'>Dihasilkan pada: " . date('d M Y H:i') . "</p>";
    echo "</div>";
}
?>
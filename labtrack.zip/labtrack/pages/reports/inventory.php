<?php
$pageTitle = "Laporan Inventaris";
// Pastikan semua dependensi dimuat DULU
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php'; // ← ini harus di-load sebelum header.php
require_once '../../includes/db_connect.php';

// Ambil data
$items = $pdo->query("SELECT * FROM inventory ORDER BY created_at DESC")->fetchAll();
?>

<!-- Baru panggil header.php setelah auth_check.php dimuat -->
<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2>🖨️ Laporan Inventaris Lab</h2>
<p class="text-muted">Dihasilkan pada: <?= date('d M Y H:i') ?></p>

<?php
printReport("Daftar Inventaris", $items, ['name', 'category', 'code', 'status', 'created_at']);
?>

<button onclick="window.print()" class="btn btn-success mt-3">🖨️ Cetak Halaman Ini</button>

<?php include '../../includes/footer.php'; ?>
<?php
$pageTitle = "Laporan Peminjaman";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

// Ambil semua data peminjaman
$bookings = $pdo->query("
    SELECT b.*, u.name AS user_name, i.name AS item_name 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN inventory i ON b.item_id = i.id
    ORDER BY b.borrow_date DESC
")->fetchAll();
?>

<!-- Header & Sidebar -->
<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2>🖨️ Laporan Peminjaman Alat</h2>
<p class="text-muted">Dihasilkan pada: <?= date('d M Y H:i') ?></p>

<?php
printReport("Daftar Peminjaman", $bookings, ['user_name', 'item_name', 'borrow_date', 'return_date', 'status']);
?>

<!-- Tombol Cetak -->
<button onclick="window.print()" class="btn btn-success mt-3">🖨️ Cetak Halaman Ini</button>

<?php include '../../includes/footer.php'; ?>
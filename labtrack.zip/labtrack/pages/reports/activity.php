<?php
$pageTitle = "Laporan Log Aktivitas";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

// Ambil semua data log aktivitas
$logs = $pdo->query("
    SELECT l.action, l.created_at, u.name AS user_name
    FROM activity_logs l
    LEFT JOIN users u ON l.user_id = u.id
    ORDER BY l.created_at DESC
")->fetchAll();

include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>🖨️ Laporan Log Aktivitas</h2>
    <button onclick="window.print()" class="btn btn-success">
        <i class="bi bi-printer"></i> Cetak Laporan
    </button>
</div>

<p class="text-muted mb-4">Dihasilkan pada: <?= date('d M Y H:i') ?></p>

<?php
// Gunakan fungsi printReport untuk menampilkan dalam format tabel
printReport("Daftar Log Aktivitas", $logs, ['user_name', 'action', 'created_at']);
?>

<?php include '../../includes/footer.php'; ?>
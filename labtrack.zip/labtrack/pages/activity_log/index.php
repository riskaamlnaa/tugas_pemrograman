<?php
$pageTitle = "Log Aktivitas";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

// Filter berdasarkan tanggal
$start_date = $_GET['start'] ?? '';
$end_date = $_GET['end'] ?? '';

$where = '';
$params = [];

if ($start_date && $end_date) {
    $where = " AND l.created_at BETWEEN ? AND ?";
    $params = [$start_date, $end_date];
} elseif ($start_date) {
    $where = " AND l.created_at >= ?";
    $params = [$start_date];
} elseif ($end_date) {
    $where = " AND l.created_at <= ?";
    $params = [$end_date];
}

$logs = $pdo->prepare("
    SELECT l.action, l.created_at, u.name AS user_name
    FROM activity_logs l
    LEFT JOIN users u ON l.user_id = u.id
    WHERE 1=1 $where
    ORDER BY l.created_at DESC
    LIMIT 200
");
$logs->execute($params);
$logs = $logs->fetchAll();
?>

<!-- Header & Sidebar -->
<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📝 Log Aktivitas Sistem</h2>
    <div>
        <a href="<?= BASE_URL ?>pages/reports/activity.php" class="btn btn-outline-secondary">
            <i class="bi bi-printer"></i> Cetak Laporan
        </a>
    </div>
</div>

<!-- Form Filter -->
<form method="GET" class="card mb-4 p-3 bg-light">
    <div class="row">
        <div class="col-md-3">
            <label class="form-label fw-bold">Dari Tanggal</label>
            <input type="datetime-local" name="start" class="form-control" value="<?= esc($start_date) ?>">
        </div>
        <div class="col-md-3">
            <label class="form-label fw-bold">Sampai Tanggal</label>
            <input type="datetime-local" name="end" class="form-control" value="<?= esc($end_date) ?>">
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filter</button>
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <a href="<?= BASE_URL ?>pages/activity_log/index.php" class="btn btn-outline-secondary w-100"><i class="bi bi-arrow-counterclockwise"></i> Reset</a>
        </div>
    </div>
</form>

<?php if (empty($logs)): ?>
    <div class="text-center py-5">
        <i class="bi bi-clipboard2-data" style="font-size: 3rem; color: #adb5bd;"></i>
        <h4 class="mt-3">Belum ada aktivitas tercatat</h4>
        <p class="text-muted">Aktivitas akan muncul setelah ada aksi (tambah, edit, pinjam, dll)</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Pengguna</th>
                    <th>Aktivitas</th>
                    <th>Waktu</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $i => $log): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($log['user_name'] ?? 'Sistem') ?></td>
                    <td><?= esc($log['action']) ?></td>
                    <td><?= formatDate($log['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
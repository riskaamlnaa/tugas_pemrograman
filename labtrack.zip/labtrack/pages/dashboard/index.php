<?php
$pageTitle = "Dashboard";
require_once '../../config.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connect.php';
include '../../includes/header.php';
include '../../includes/sidebar.php';

// Data Ringkasan
$totalItems = $pdo->query("SELECT COUNT(*) FROM inventory")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status = 'dipinjam'")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$recentLogs = $pdo->query("
    SELECT l.action, l.created_at, u.name
    FROM activity_logs l
    JOIN users u ON l.user_id = u.id
    ORDER BY l.created_at DESC LIMIT 5
")->fetchAll();

// Status Alat (Chart Data)
$statusData = $pdo->query("
    SELECT status, COUNT(*) as count FROM inventory GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);
$tersedia = $statusData['tersedia'] ?? 0;
$dipinjam = $statusData['dipinjam'] ?? 0;
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center mb-4">
    <h1 class="h3 fw-bold">📊 Dashboard LabTrack</h1>
    <div class="btn-group">
        <?php if ($_SESSION['role'] !== 'user'): ?>
        <a href="<?= BASE_URL ?>pages/inventory/create.php" class="btn btn-primary">➕ Tambah Alat</a>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>pages/bookings/create.php" class="btn btn-success">📅 Ajukan Peminjaman</a>
    </div>
</div>

<!-- Statistik Kartu -->
<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-white bg-gradient-primary">
            <div class="card-body text-center">
                <h5 class="card-title">Inventaris</h5>
                <h2 class="display-5"><?= $totalItems ?></h2>
                <p class="mb-0">Alat Tersedia: <?= $tersedia ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-white bg-gradient-warning">
            <div class="card-body text-center">
                <h5 class="card-title">Dipinjam</h5>
                <h2 class="display-5"><?= $pending ?></h2>
                <p class="mb-0">Alat Sedang Digunakan</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-white bg-gradient-success">
            <div class="card-body text-center">
                <h5 class="card-title">Pengguna</h5>
                <h2 class="display-5"><?= $totalUsers ?></h2>
                <p class="mb-0">Aktif di Sistem</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm text-white bg-gradient-info">
            <div class="card-body text-center">
                <h5 class="card-title">Status Alat</h5>
                <div class="mt-2">
                    <small>Tersedia: <strong><?= $tersedia ?></strong></small><br>
                    <small>Dipinjam: <strong><?= $dipinjam ?></strong></small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Aktivitas Terbaru -->
<div class="card shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <h5 class="mb-0">📝 Aktivitas Terbaru</h5>
        <a href="<?= BASE_URL ?>pages/activity_log/index.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
    </div>
    <div class="card-body">
        <?php if ($recentLogs): ?>
            <ul class="list-group list-group-flush">
                <?php foreach ($recentLogs as $log): ?>
                <li class="list-group-item">
                    <small class="text-muted"><?= formatDate($log['created_at']) ?></small><br>
                    <strong><?= esc($log['name']) ?></strong> <?= esc($log['action']) ?>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-muted text-center mt-3">Belum ada aktivitas.</p>
        <?php endif; ?>
    </div>
</div>

<style>
.bg-gradient-primary { background: linear-gradient(135deg, #4361ee, #3a0ca3); }
.bg-gradient-warning { background: linear-gradient(135deg, #ff9e00, #f46b2a); }
.bg-gradient-success { background: linear-gradient(135deg, #06d6a0, #118ab2); }
.bg-gradient-info { background: linear-gradient(135deg, #073b4c, #118ab2); }
</style>

<?php include '../../includes/footer.php'; ?>
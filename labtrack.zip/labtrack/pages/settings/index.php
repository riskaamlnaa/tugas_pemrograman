<?php
$pageTitle = "Pengaturan";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin']);
?>

<h2>Pengaturan Sistem</h2>

<div class="card">
    <div class="card-body">
        <h5>Informasi Aplikasi</h5>
        <p><strong>Nama:</strong> <?= APP_NAME ?></p>
        <p><strong>Versi:</strong> <?= APP_VERSION ?></p>
        <p><strong>Database:</strong> <?= DB_NAME ?></p>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
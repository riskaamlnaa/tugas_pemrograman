<?php
$pageTitle = "Edit Alat Lab";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

$item_id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ?");
$stmt->execute([$item_id]);
$item = $stmt->fetch();

if (!$item) {
    header("Location: index.php");
    exit();
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $cat = trim($_POST['category'] ?? '');

    if ($name && $cat) {
        $update = $pdo->prepare("UPDATE inventory SET name = ?, description = ?, category = ? WHERE id = ?");
        if ($update->execute([$name, $desc, $cat, $item_id])) {
            // Catat log
            $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
                ->execute([$_SESSION['user_id'], "Mengedit inventaris: " . $name]);

            flashMessage("✅ Alat berhasil diperbarui!", "success");
            header("Location: view.php?id=" . $item_id);
            exit();
        } else {
            $message = "❌ Gagal memperbarui data.";
        }
    } else {
        $message = "⚠️ Nama dan kategori wajib diisi.";
    }
}
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2 class="mb-4">Edit Alat Lab</h2>

<?php if ($message): ?>
    <div class="alert alert-warning"><?= esc($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Alat</label>
        <input type="text" class="form-control" name="name" value="<?= esc($item['name']) ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Kategori</label>
        <input type="text" class="form-control" name="category" value="<?= esc($item['category']) ?>" required>
    </div>
    <div class="col-12">
        <label class="form-label">Deskripsi</label>
        <textarea class="form-control" name="description" rows="3"><?= esc($item['description']) ?></textarea>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">💾 Simpan Perubahan</button>
        <a href="view.php?id=<?= $item['id'] ?>" class="btn btn-secondary">↩️ Batal</a>
    </div>
</form>

<?php include '../../includes/footer.php'; ?>
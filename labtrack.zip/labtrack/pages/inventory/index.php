<?php
$pageTitle = "Inventaris Lab";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

// Ambil semua data inventaris
$items = $pdo->query("SELECT * FROM inventory ORDER BY created_at DESC")->fetchAll();
?>

<!-- Header & Sidebar -->
<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>🧪 Inventaris Laboratorium</h2>
    <div>
        <a href="<?= BASE_URL ?>pages/inventory/create.php" class="btn btn-primary">
            <i class="bi bi-plus-circle"></i> Tambah Alat
        </a>
        <a href="<?= BASE_URL ?>pages/reports/inventory.php" class="btn btn-outline-secondary ms-2">
            <i class="bi bi-printer"></i> Cetak Laporan
        </a>
    </div>
</div>

<?php if (empty($items)): ?>
    <div class="text-center py-5">
        <div class="mb-3">
            <i class="bi bi-box-seam" style="font-size: 3rem; color: #adb5bd;"></i>
        </div>
        <h4>Belum ada alat laboratorium terdaftar</h4>
        <p class="text-muted">Mulai dengan menambahkan alat pertama Anda.</p>
        <a href="<?= BASE_URL ?>pages/inventory/create.php" class="btn btn-primary mt-3">➕ Tambah Alat Pertama</a>
    </div>
<?php else: ?>
    <div class="row g-4">
        <?php foreach ($items as $item): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= esc($item['name']) ?></h5>
                    
                    <div class="mt-2 text-muted small">
                        <p><strong>Kode:</strong> <?= esc($item['code']) ?></p>
                        <p><strong>Kategori:</strong> <?= esc($item['category']) ?></p>
                        <?php if (!empty($item['description'])): ?>
                            <p><strong>Deskripsi:</strong><br><?= nl2br(esc($item['description'])) ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="mt-auto">
                        <span class="badge rounded-pill
                            <?= $item['status'] == 'tersedia' ? 'bg-success' : 'bg-warning text-dark' ?>">
                            <?= $item['status'] == 'tersedia' ? 'Tersedia' : 'Sedang Dipinjam' ?>
                        </span>

                        <div class="mt-3 d-flex gap-2">
                            <a href="<?= BASE_URL ?>pages/inventory/view.php?id=<?= $item['id'] ?>"
                               class="btn btn-sm btn-outline-primary flex-grow-1">
                                🔍 Detail
                            </a>
                            <?php if ($_SESSION['role'] !== 'user'): ?>
                            <a href="<?= BASE_URL ?>pages/inventory/edit.php?id=<?= $item['id'] ?>"
                               class="btn btn-sm btn-warning">
                                ✏️ Edit
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
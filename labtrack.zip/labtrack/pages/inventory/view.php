<?php
$pageTitle = "Detail Item";
require_once '../../config.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connect.php';
include '../../includes/header.php';
include '../../includes/sidebar.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    header("Location: index.php");
    exit();
}
?>

<h2><?= esc($item['name']) ?></h2>
<p><strong>Kode:</strong> <?= esc($item['code']) ?></p>
<?php if ($item['qr_code'] && file_exists(QR_CODE_PATH . $item['qr_code'])): ?>
    <img src="<?= BASE_URL . QR_CODE_PATH . $item['qr_code'] ?>" class="img-fluid" style="max-width:200px;">
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
<?php
require_once '../../config.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

$item_id = $_GET['id'] ?? 0;
if (!$item_id) {
    header("Location: index.php");
    exit();
}

// Ambil nama sebelum hapus
$stmt = $pdo->prepare("SELECT name FROM inventory WHERE id = ?");
$stmt->execute([$item_id]);
$item = $stmt->fetch();

if ($item) {
    // Hapus dari database
    $pdo->prepare("DELETE FROM inventory WHERE id = ?")->execute([$item_id]);

    // Catat log
    $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
        ->execute([$_SESSION['user_id'], "Menghapus inventaris: " . $item['name']]);

    flashMessage("✅ Alat berhasil dihapus.", "success");
}

header("Location: index.php");
exit();
?>
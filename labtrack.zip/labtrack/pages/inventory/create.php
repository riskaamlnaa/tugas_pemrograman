<?php
$pageTitle = "Tambah Alat Lab";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $cat = trim($_POST['category'] ?? '');

    if ($name && $cat) {
        try {
            // Generate kode unik
            $code = 'INV' . strtoupper(substr(uniqid(), -6));

            // Simpan ke database
            $stmt = $pdo->prepare("INSERT INTO inventory (name, description, category, code, status) VALUES (?, ?, ?, ?, 'tersedia')");
            $stmt->execute([$name, $desc, $cat, $code]);
            $item_id = $pdo->lastInsertId();

            // Catat ke log aktivitas
            $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
                ->execute([$_SESSION['user_id'], "Menambahkan inventaris: " . $name]);

            flashMessage("✅ Alat berhasil ditambahkan!", "success");
            header("Location: index.php");
            exit();

        } catch (Exception $e) {
            $message = "❌ Gagal: " . $e->getMessage();
        }
    } else {
        $message = "⚠️ Nama dan kategori wajib diisi.";
    }
}
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2 class="mb-4">Tambah Alat Lab</h2>

<?php if ($message): ?>
    <div class="alert alert-warning"><?= esc($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Alat</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Kategori</label>
        <input type="text" class="form-control" name="category" placeholder="Contoh: Alat Ukur, Bahan Kimia" required>
    </div>
    <div class="col-12">
        <label class="form-label">Deskripsi (Opsional)</label>
        <textarea class="form-control" name="description" rows="3"></textarea>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-success">✅ Simpan Alat</button>
        <a href="index.php" class="btn btn-secondary">↩️ Batal</a>
    </div>
</form>

<?php include '../../includes/footer.php'; ?>
<?php
$pageTitle = "Scan QR Code";
require_once '../../includes/auth_check.php';
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<h2>Scan QR Code Alat Lab</h2>
<p class="text-muted">Arahkan kamera ke QR Code pada alat untuk melihat detail atau ajukan peminjaman.</p>

<div class="card">
    <div class="card-body text-center">
        <div id="qr-reader" style="width: 100%; max-width: 500px; margin: 0 auto;"></div>
        <div id="qr-result" class="mt-3 alert alert-success d-none"></div>
        <p class="mt-2">
            <small class="text-muted">
                Izinkan akses kamera saat diminta. Hanya bekerja di perangkat dengan kamera.
            </small>
        </p>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>

<!-- HTML5 QR Code Scanner -->
<script src="<?= BASE_URL ?>assets/js/html5-qrcode.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const qrReader = document.getElementById('qr-reader');
    const qrResult = document.getElementById('qr-result');

    const html5QrCode = new Html5Qrcode("qr-reader");

    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    html5QrCode.start(
        { facingMode: "environment" }, // Gunakan kamera belakang di HP
        config,
        (decodedText, decodedResult) => {
            // Berhentikan scanning
            html5QrCode.stop().then(() => {
                // Tampilkan hasil
                qrResult.classList.remove('d-none');
                qrResult.innerHTML = `✅ QR terdeteksi! Mengarahkan ke: <strong>${decodedText}</strong>`;
                
                // Redirect ke URL yang ada di QR (misal: .../view.php?id=5)
                setTimeout(() => {
                    window.location.href = decodedText;
                }, 1500);
            }).catch(err => {
                console.warn("Gagal berhenti scanning:", err);
            });
        },
        (errorMessage) => {
            // Error scanning (opsional)
        }
    ).catch(err => {
        qrResult.classList.remove('d-none');
        qrResult.className = 'alert alert-danger';
        qrResult.innerHTML = '❌ Gagal mengakses kamera. Pastikan izin diberikan dan perangkat punya kamera.';
    });
});
</script>
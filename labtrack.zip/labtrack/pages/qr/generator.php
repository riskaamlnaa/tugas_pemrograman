<?php
$pageTitle = "Generator QR Code";
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
include '../../includes/header.php';
include '../../includes/sidebar.php';

$qr_url = '';
$qr_image = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = $_POST['item_id'] ?? '';
    if ($item_id) {
        $qr_url = BASE_URL . "pages/inventory/view.php?id=" . (int)$item_id;
        // Simpan sementara di session atau generate langsung
        $qr_image = 'data:image/png;base64,' . base64_encode(
            file_get_contents('https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qr_url))
        );
    }
}
?>

<h2>Generator QR Code Manual</h2>
<p class="text-muted">Buat QR Code untuk item inventaris yang sudah ada.</p>

<form method="POST" class="row g-3 mb-4">
    <div class="col-md-8">
        <label class="form-label">Pilih Item Inventaris</label>
        <select name="item_id" class="form-select" required>
            <option value="">-- Pilih Item --</option>
            <?php
            require_once '../../includes/db_connect.php';
            $items = $pdo->query("SELECT id, name, code FROM inventory ORDER BY name")->fetchAll();
            foreach ($items as $item) {
                echo '<option value="' . $item['id'] . '">' . esc($item['name']) . ' (' . esc($item['code']) . ')</option>';
            }
            ?>
        </select>
    </div>
    <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary">Buat QR Code</button>
    </div>
</form>

<?php if ($qr_image): ?>
<div class="card">
    <div class="card-body text-center">
        <h5>QR Code untuk: <?= $qr_url ?></h5>
        <img src="<?= $qr_image ?>" alt="QR Code" class="img-fluid border p-2" style="max-width: 250px;">
        <p class="mt-2">
            <a href="<?= $qr_image ?>" download="qr_item_<?= $_POST['item_id'] ?>.png" class="btn btn-success btn-sm">
                📥 Unduh QR
            </a>
        </p>
    </div>
</div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
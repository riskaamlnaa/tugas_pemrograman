<?php
$pageTitle = "Riwayat Peminjaman";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connect.php';

// Ambil riwayat peminjaman untuk pengguna yang login
$user_id = $_SESSION['user_id'];

// Gunakan prepared statement untuk menghindari error
$stmt = $pdo->prepare("SELECT b.*, i.name AS item_name 
                      FROM bookings b 
                      JOIN inventory i ON b.item_id = i.id 
                      WHERE b.user_id = ? 
                      ORDER BY b.created_at DESC");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();

// Tampilkan halaman
include '../../includes/header.php';
include '../../includes/sidebar.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Riwayat Peminjaman Saya</h2>
    <a href="<?= BASE_URL ?>pages/bookings/create.php" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Ajukan Peminjaman
    </a>
</div>

<?php if (empty($bookings)): ?>
    <div class="alert alert-info">Belum ada riwayat peminjaman.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Alat</th>
                    <th>Tgl Pinjam</th>
                    <th>Tgl Kembali</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $i => $b): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($b['item_name']) ?></td>
                    <td><?= formatDate($b['borrow_date']) ?></td>
                    <td><?= $b['return_date'] ? formatDate($b['return_date']) : '-' ?></td>
                    <td>
                        <span class="badge rounded-pill
                            <?= $b['status'] == 'menunggu' ? 'bg-warning text-dark' :
                                ($b['status'] == 'dipinjam' ? 'bg-primary text-light' :
                                ($b['status'] == 'dikembalikan' ? 'bg-success text-light' : 'bg-danger')) ?>">
                            <?= ucfirst(esc($b['status'])) ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($b['status'] == 'dipinjam'): ?>
                            <a href="return.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-info">Kembalikan</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
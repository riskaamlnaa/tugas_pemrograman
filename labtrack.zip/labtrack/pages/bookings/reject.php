<?php
// Muat semua dependensi di awal
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

$booking_id = $_GET['id'] ?? 0;
if (!$booking_id) {
    flashMessage("❌ ID peminjaman tidak valid.", "error");
    header("Location: index.php");
    exit();
}

// Ambil data peminjaman
$stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    flashMessage("❌ Peminjaman tidak ditemukan.", "error");
    header("Location: index.php");
    exit();
}

// Update status peminjaman
$pdo->prepare("UPDATE bookings SET status = 'ditolak' WHERE id = ?")
    ->execute([$booking_id]);

// Catat ke log aktivitas
$user_name = $_SESSION['name'] ?? 'Sistem';
$item_name = 'Item #' . $booking['item_id'];
$pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
    ->execute([$_SESSION['user_id'], "$user_name menolak peminjaman $item_name"]);

flashMessage("✅ Peminjaman berhasil ditolak!", "success");
header("Location: index.php");
exit();
?>
<?php
$pageTitle = "Kembalikan Alat";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

$booking_id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("
    SELECT b.*, u.name AS user_name, i.name AS item_name 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN inventory i ON b.item_id = i.id
    WHERE b.id = ? AND b.status = 'dipinjam'
");
$stmt->execute([$booking_id]);
$booking = $stmt->fetch();

if (!$booking) {
    flashMessage("❌ Peminjaman tidak ditemukan atau sudah dikembalikan.", "error");
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update status peminjaman
    $pdo->prepare("UPDATE bookings SET status = 'dikembalikan', return_date = NOW() WHERE id = ?")
        ->execute([$booking_id]);

    // Update status inventaris
    $pdo->prepare("UPDATE inventory SET status = 'tersedia' WHERE id = ?")
        ->execute([$booking['item_id']]);

    // Catat log
    $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
        ->execute([$_SESSION['user_id'], "Mengembalikan alat: " . $booking['item_name']]);

    flashMessage("✅ Alat berhasil dikembalikan.", "success");
    header("Location: index.php");
    exit();
}
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2>Konfirmasi Pengembalian</h2>

<div class="card mb-4">
    <div class="card-body">
        <p><strong>Peminjam:</strong> <?= esc($booking['user_name']) ?></p>
        <p><strong>Alat:</strong> <?= esc($booking['item_name']) ?></p>
        <p><strong>Dipinjam sejak:</strong> <?= formatDate($booking['borrow_date']) ?></p>
    </div>
</div>

<form method="POST">
    <p>Apakah alat ini sudah dikembalikan dalam kondisi baik?</p>
    <button type="submit" class="btn btn-success">✅ Ya, Konfirmasi Pengembalian</button>
    <a href="index.php" class="btn btn-secondary">Batal</a>
</form>

<?php include '../../includes/footer.php'; ?>
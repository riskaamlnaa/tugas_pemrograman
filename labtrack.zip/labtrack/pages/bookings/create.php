<?php
$pageTitle = "Ajukan Peminjaman";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connect.php';

$user_id = $_SESSION['user_id'];

// Ambil item_id dari URL (jika ada)
$item_id = $_GET['item_id'] ?? null;
$preselectedItem = null;
if ($item_id) {
    $stmt = $pdo->prepare("SELECT id, name FROM inventory WHERE id = ? AND status = 'tersedia'");
    $stmt->execute([$item_id]);
    $preselectedItem = $stmt->fetch();
}

// Daftar item tersedia
$availableItems = $pdo->query("SELECT id, name, code FROM inventory WHERE status = 'tersedia'")->fetchAll();

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = $_POST['item_id'] ?? '';
    $borrow_date = $_POST['borrow_date'] ?? '';
    $return_date = $_POST['return_date'] ?? '';

    if ($item_id && $borrow_date && $return_date) {
        // Cek apakah item tersedia
        $check = $pdo->prepare("SELECT status FROM inventory WHERE id = ?");
        $check->execute([$item_id]);
        $status = $check->fetchColumn();

        if ($status !== 'tersedia') {
            $message = "❌ Maaf, alat ini sudah tidak tersedia.";
        } elseif (strtotime($return_date) <= strtotime($borrow_date)) {
            $message = "❌ Tanggal kembali harus setelah tanggal peminjaman.";
        } else {
            // Simpan peminjaman (status: menunggu)
            $stmt = $pdo->prepare("
                INSERT INTO bookings (user_id, item_id, borrow_date, return_date, status)
                VALUES (?, ?, ?, ?, 'menunggu')
            ");
            if ($stmt->execute([$user_id, $item_id, $borrow_date, $return_date])) {
                // Catat log
                $item_name = $_POST['item_name'] ?? 'Alat Lab';
                $pdo->prepare("INSERT INTO activity_logs (user_id, action) VALUES (?, ?)")
                    ->execute([$user_id, "Mengajukan peminjaman: " . $item_name]);

                flashMessage("✅ Peminjaman berhasil diajukan. Menunggu persetujuan.", "success");
                header("Location: history.php");
                exit();
            } else {
                $message = "❌ Gagal mengajukan peminjaman.";
            }
        }
    } else {
        $message = "⚠️ Semua kolom wajib diisi.";
    }
}
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2 class="mb-4">Ajukan Peminjaman Alat</h2>

<?php if ($message): ?>
    <div class="alert alert-danger"><?= esc($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">
    <div class="col-12">
        <label class="form-label">Pilih Alat</label>
        <select class="form-select" name="item_id" required onchange="updateItemName(this)">
            <option value="">-- Pilih Alat Tersedia --</option>
            <?php foreach ($availableItems as $item): ?>
            <option value="<?= $item['id'] ?>" <?= ($preselectedItem && $preselectedItem['id'] == $item['id']) ? 'selected' : '' ?>>
                <?= esc($item['name']) ?> (<?= esc($item['code']) ?>)
            </option>
            <?php endforeach; ?>
        </select>
        <input type="hidden" name="item_name" id="item_name">
    </div>
    <div class="col-md-6">
        <label class="form-label">Tanggal Pinjam</label>
        <input type="date" class="form-control" name="borrow_date" value="<?= date('Y-m-d') ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Tanggal Kembali</label>
        <input type="date" class="form-control" name="return_date" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">📤 Ajukan Peminjaman</button>
        <a href="../inventory/index.php" class="btn btn-secondary">Pilih dari Daftar Inventaris</a>
    </div>
</form>

<script>
function updateItemName(select) {
    const selected = select.options[select.selectedIndex];
    document.getElementById('item_name').value = selected.text.split(' (')[0] || selected.value;
}
</script>

<?php include '../../includes/footer.php'; ?>
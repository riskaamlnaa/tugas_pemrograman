<?php
$pageTitle = "Daftar Peminjaman";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin', 'petugas']);
require_once '../../includes/db_connect.php';

// Ambil semua peminjaman
$bookings = $pdo->query("
    SELECT b.*, u.name AS user_name, i.name AS item_name 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN inventory i ON b.item_id = i.id
    ORDER BY b.created_at DESC
")->fetchAll();
?>

<!-- Header & Sidebar -->
<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>📅 Daftar Peminjaman</h2>
    <div>
        <a href="<?= BASE_URL ?>pages/bookings/create.php" class="btn btn-primary">➕ Ajukan Peminjaman</a>
        <a href="<?= BASE_URL ?>pages/reports/bookings.php" class="btn btn-outline-secondary ms-2">
            <i class="bi bi-printer"></i> Cetak Laporan
        </a>
    </div>
</div>

<?php if (empty($bookings)): ?>
    <div class="text-center py-5">
        <i class="bi bi-box-seam" style="font-size: 3rem; color: #adb5bd;"></i>
        <h4 class="mt-3">Belum ada peminjaman tercatat</h4>
        <p class="text-muted">Mulai dengan mengajukan peminjaman alat.</p>
        <a href="<?= BASE_URL ?>pages/bookings/create.php" class="btn btn-primary mt-3">➕ Ajukan Peminjaman Pertama</a>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Peminjam</th>
                    <th>Alat</th>
                    <th>Tgl Pinjam</th>
                    <th>Tgl Kembali</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $i => $b): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($b['user_name']) ?></td>
                    <td><?= esc($b['item_name']) ?></td>
                    <td><?= formatDate($b['borrow_date']) ?></td>
                    <td><?= $b['return_date'] ? formatDate($b['return_date']) : '-' ?></td>
                    <td>
                        <span class="badge rounded-pill
                            <?= $b['status'] == 'menunggu' ? 'bg-warning text-dark' :
                                ($b['status'] == 'dipinjam' ? 'bg-primary' :
                                ($b['status'] == 'dikembalikan' ? 'bg-success' : 'bg-danger')) ?>">
                            <?= ucfirst(esc($b['status'])) ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($_SESSION['role'] !== 'user'): ?>
                            <?php if ($b['status'] == 'menunggu'): ?>
                                <a href="approve.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-success">
                                    <i class="bi bi-check-lg"></i> Setujui
                                </a>
                                <a href="reject.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-danger">
                                    <i class="bi bi-x-lg"></i> Tolak
                                </a>
                            <?php elseif ($b['status'] == 'dipinjam'): ?>
                                <a href="return.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-arrow-counterclockwise"></i> Kembalikan
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
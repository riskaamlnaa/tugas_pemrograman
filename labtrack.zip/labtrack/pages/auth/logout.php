<?php
// Logout dengan aman
session_start();
require_once '../../config.php';

// Hapus semua data sesi
$_SESSION = array();
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

// Redirect ke login dengan pesan
header("Location: " . BASE_URL . "pages/auth/login.php?logged_out=1");
exit();
?>
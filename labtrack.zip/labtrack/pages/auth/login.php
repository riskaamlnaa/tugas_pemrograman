<?php
session_start();

// Redirect jika sudah login
if (isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "pages/dashboard/index.php");
    exit();
}

require_once '../../config.php';

// Pesan logout
$logout_message = '';
if (isset($_GET['logged_out']) && $_GET['logged_out'] == 1) {
    $logout_message = "✅ Anda telah berhasil keluar dari sistem.";
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        require_once '../../includes/db_connect.php';
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            // Redirect berdasarkan role
            switch ($user['role']) {
                case 'admin':
                    header("Location: " . BASE_URL . "pages/dashboard/index.php");
                    break;
                case 'petugas':
                    header("Location: " . BASE_URL . "pages/inventory/index.php");
                    break;
                default:
                    header("Location: " . BASE_URL . "pages/bookings/create.php");
            }
            exit();
        } else {
            $error = "📧 Email atau 🔒 password salah.";
        }
    } else {
        $error = "⚠️ Harap isi email dan password.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — LabTrack</title>
    <link href="<?= BASE_URL ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            max-width: 450px;
            width: 100%;
        }
        .logo {
            width: 80px;
            height: 80px;
            margin: -50px auto 20px;
            border: 4px solid white;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo img {
            width: 50px;
        }
        .btn-login {
            background: linear-gradient(to right, #4361ee, #3a0ca3);
            border: none;
            padding: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .btn-login:hover {
            background: linear-gradient(to right, #3a0ca3, #4361ee);
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(67, 97, 238, 0.4);
        }
        .form-control:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25);
        }
        .alert-success {
            background: #d1f0e5;
            color: #0a644d;
            border: none;
            border-radius: 12px;
        }
        .alert-danger {
            background: #fdecea;
            color: #c02d35;
            border: none;
            border-radius: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-card mx-auto p-4">
            <div class="logo">
                <img src="<?= BASE_URL ?>assets/images/logo.png" alt="LabTrack">
            </div>
            <h3 class="text-center fw-bold mb-1">🧪 Selamat Datang di LabTrack</h3>
            <p class="text-center text-muted mb-4">Silakan login untuk mengakses sistem</p>

            <?php if ($logout_message): ?>
                <div class="alert alert-success text-center"><?= htmlspecialchars($logout_message) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">📧 Email</label>
                    <input type="email" class="form-control form-control-lg" id="email" name="email" placeholder="contoh@labtrack.com" required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label">🔒 Password</label>
                    <input type="password" class="form-control form-control-lg" id="password" name="password" placeholder="••••••••" required>
                </div>
                <button type="submit" class="btn btn-login text-white w-100 py-3">👉 MASUK</button>
            </form>

            <div class="text-center mt-4">
                <small class="text-muted">
                    &copy; <?= date('Y') ?> LabTrack • Sistem Peminjaman & Inventaris Lab
                </small>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$pageTitle = "Akses Ditolak";
include '../../includes/header.php';
?>

<div class="container mt-5">
    <div class="text-center">
        <h1 class="display-1 text-danger">403</h1>
        <h2>Akses Ditolak</h2>
        <p class="lead">Anda tidak memiliki izin untuk mengakses halaman ini.</p>
        <a href="<?= BASE_URL ?>pages/dashboard/index.php" class="btn btn-primary">Kembali ke Dashboard</a>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
<?php
$pageTitle = "Halaman Tidak Ditemukan";
include '../../includes/header.php';
?>

<div class="container mt-5">
    <div class="text-center">
        <h1 class="display-1 text-warning">404</h1>
        <h2>Halaman Tidak Ditemukan</h2>
        <p class="lead">Maaf, halaman yang Anda cari tidak tersedia.</p>
        <a href="<?= BASE_URL ?>pages/dashboard/index.php" class="btn btn-primary">Kembali ke Dashboard</a>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
<?php
$pageTitle = "Edit Pengguna";
require_once '../../includes/auth_check.php';
requireRole(['admin']);
require_once '../../includes/db_connect.php';
include '../../includes/header.php';
include '../../includes/sidebar.php';

$user_id = $_GET['id'] ?? 0;
if (!$user_id || $user_id == $_SESSION['user_id']) {
    flashMessage("Tidak bisa mengedit diri sendiri di halaman ini.", "warning");
    header("Location: index.php");
    exit();
}

// Ambil data pengguna
$stmt = $pdo->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if (!$user) {
    header("Location: index.php");
    exit();
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';

    if ($name && $email && $role) {
        // Cek duplikat email (kecuali milik diri sendiri)
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check->execute([$email, $user_id]);
        if ($check->fetch()) {
            $message = "Email sudah digunakan.";
        } elseif (!in_array($role, ['admin', 'petugas', 'user'])) {
            $message = "Peran tidak valid.";
        } else {
            $update = $pdo->prepare("UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?");
            if ($update->execute([$name, $email, $role, $user_id])) {
                flashMessage("Pengguna berhasil diperbarui.", "success");
                header("Location: index.php");
                exit();
            } else {
                $message = "Gagal memperbarui data.";
            }
        }
    } else {
        $message = "Semua kolom wajib diisi.";
    }
}
?>

<h2>Edit Pengguna</h2>

<?php if ($message): ?>
    <div class="alert alert-danger"><?= esc($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" class="form-control" name="name" value="<?= esc($user['name']) ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" value="<?= esc($user['email']) ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Peran</label>
        <select class="form-select" name="role" required>
            <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
            <option value="petugas" <?= $user['role'] == 'petugas' ? 'selected' : '' ?>>Petugas Lab</option>
            <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>Mahasiswa/Dosen</option>
        </select>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </div>
</form>

<?php include '../../includes/footer.php'; ?>
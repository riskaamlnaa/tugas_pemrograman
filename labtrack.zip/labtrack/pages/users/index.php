<?php
$pageTitle = "Daftar Pengguna";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin']); // Hanya admin yang boleh akses
require_once '../../includes/db_connect.php';

$users = $pdo->query("SELECT id, name, email, role FROM users ORDER BY created_at DESC")->fetchAll();
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>👥 Daftar Pengguna</h2>
    <a href="<?= BASE_URL ?>pages/users/create.php" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tambah Pengguna
    </a>
</div>

<?php if (empty($users)): ?>
    <div class="alert alert-info">Belum ada pengguna.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead class="table-light">
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Peran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= esc($user['name']) ?></td>
                    <td><?= esc($user['email']) ?></td>
                    <td><?= ucfirst(esc($user['role'])) ?></td>
                    <td>
                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                        <a href="edit.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-warning">✏️ Edit</a>
                        <a href="delete.php?id=<?= $user['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus pengguna ini?')">🗑️ Hapus</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
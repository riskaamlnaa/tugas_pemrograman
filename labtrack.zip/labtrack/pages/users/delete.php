<?php
require_once '../../includes/auth_check.php';
requireRole(['admin']);
require_once '../../includes/db_connect.php';

$user_id = $_GET['id'] ?? 0;
if ($user_id && $user_id != $_SESSION['user_id']) {
    // Cegah hapus diri sendiri
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$user_id]);
    flashMessage("Pengguna berhasil dihapus.", "success");
}

header("Location: index.php");
exit();
?>
<?php
$pageTitle = "Tambah Pengguna";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
requireRole(['admin']);

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($name && $email && $role && $password) {
        require_once '../../includes/db_connect.php';

        // Cek duplikat email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $message = "❌ Email sudah terdaftar.";
        } elseif (!in_array($role, ['admin', 'petugas', 'user'])) {
            $message = "❌ Peran tidak valid.";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, role, password) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $role, $hash])) {
                flashMessage("✅ Pengguna berhasil ditambahkan.", "success");
                header("Location: index.php");
                exit();
            } else {
                $message = "❌ Gagal menyimpan data.";
            }
        }
    } else {
        $message = "❌ Semua kolom wajib diisi.";
    }
}
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2 class="mb-4">Tambah Pengguna Baru</h2>

<?php if ($message): ?>
    <div class="alert alert-danger"><?= esc($message) ?></div>
<?php endif; ?>

<form method="POST" class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Password</label>
        <input type="password" class="form-control" name="password" minlength="6" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Peran</label>
        <select class="form-select" name="role" required>
            <option value="">Pilih...</option>
            <option value="admin">Admin</option>
            <option value="petugas">Petugas Lab</option>
            <option value="user">Dosen/Mahasiswa</option>
        </select>
    </div>
    <div class="col-12">
        <button type="submit" class="btn btn-primary">✅ Simpan Pengguna</button>
        <a href="index.php" class="btn btn-secondary">↩️ Batal</a>
    </div>
</form>

<?php include '../../includes/footer.php'; ?>
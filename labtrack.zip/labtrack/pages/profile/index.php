<?php
$pageTitle = "Profil Saya";
require_once '../../config.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connect.php';

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Ambil 5 aktivitas terakhir user
$logs = $pdo->prepare("
    SELECT action, created_at 
    FROM activity_logs 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 5
");
$logs->execute([$user_id]);
$myLogs = $logs->fetchAll();
?>

<?php include '../../includes/header.php'; ?>
<?php include '../../includes/sidebar.php'; ?>

<h2>👤 Profil Saya</h2>

<div class="row">
    <!-- Info Profil -->
    <div class="col-md-5">
        <div class="card shadow-sm">
            <div class="card-body text-center">
                <img src="<?= BASE_URL ?>assets/images/default-avatar.png" 
                     class="rounded-circle mb-3" width="120" height="120">
                <h4 class="card-title"><?= esc($user['name']) ?></h4>
                <p class="text-muted"><?= esc($user['email']) ?></p>
                <span class="badge rounded-pill bg-<?= 
                    $user['role'] == 'admin' ? 'danger' : 
                    ($user['role'] == 'petugas' ? 'warning' : 'info') 
                ?>">
                    <?= ucfirst(esc($user['role'])) ?>
                </span>
            </div>
        </div>
    </div>

    <!-- Riwayat Aktivitas -->
    <div class="col-md-7">
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h5 class="mb-0">📋 Aktivitas Terbaru</h5>
            </div>
            <div class="card-body">
                <?php if ($myLogs): ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($myLogs as $log): ?>
                        <li class="list-group-item">
                            <?= esc($log['action']) ?>
                            <br><small class="text-muted"><?= formatDate($log['created_at']) ?></small>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted">Belum ada aktivitas.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tombol Cetak -->
        <div class="text-end mt-3">
            <button onclick="window.print()" class="btn btn-outline-primary">
                <i class="bi bi-printer"></i> Cetak Profil
            </button>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>
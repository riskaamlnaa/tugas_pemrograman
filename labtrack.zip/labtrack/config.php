<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'labtrack_db');
define('DB_USER', 'root');
define('DB_PASS', '');

define('APP_NAME', 'LabTrack');
define('QR_CODE_PATH', 'assets/uploads/qrcodes/');
define('AVATAR_PATH', 'assets/uploads/avatars/');
define('BASE_URL', 'http://localhost/labtrack/');

date_default_timezone_set('Asia/Jakarta');
?>
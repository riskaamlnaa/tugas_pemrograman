// assets/js/main.js
document.addEventListener('DOMContentLoaded', function() {
    // Contoh: Konfirmasi hapus
    const deleteLinks = document.querySelectorAll('[data-confirm]');
    deleteLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (!confirm(this.getAttribute('data-confirm'))) {
                e.preventDefault();
            }
        });
    });
});
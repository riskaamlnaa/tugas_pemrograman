<?php
session_start();
require_once 'config.php';
require_once 'includes/db_connect.php';

if (isset($_SESSION['user_id'])) {
    header("Location: pages/dashboard/index.php");
    exit();
} else {
    header("Location: pages/auth/login.php");
    exit();
}
?>